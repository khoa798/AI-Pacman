# search.py
# ---------
# Licensing Information: Please do not distribute or publish solutions to this
# project. You are free to use and extend these projects for educational
# purposes. The Pacman AI projects were developed at UC Berkeley, primarily by
# John DeNero (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# For more info, see http://inst.eecs.berkeley.edu/~cs188/sp09/pacman.html

"""
In search.py, you will implement generic search algorithms which are called 
by Pacman agents (in searchAgents.py).
"""

import util

class SearchProblem:
  """
  This class outlines the structure of a search problem, but doesn't implement
  any of the methods (in object-oriented terminology: an abstract class).
  
  You do not need to change anything in this class, ever.
  """
  
  def startingState(self):
    """
    Returns the start state for the search problem 
    """
    util.raiseNotDefined()

  def isGoal(self, state): #isGoal -> isGoal
    """
    state: Search state

    Returns True if and only if the state is a valid goal state
    """
    util.raiseNotDefined()

  def successorStates(self, state): #successorStates -> successorsOf
    """
    state: Search state
     For a given state, this should return a list of triples, 
     (successor, action, stepCost), where 'successor' is a 
     successor to the current state, 'action' is the action
     required to get there, and 'stepCost' is the incremental 
     cost of expanding to that successor
    """
    util.raiseNotDefined()

  def actionsCost(self, actions): #actionsCost -> actionsCost
    """
      actions: A list of actions to take
 
     This method returns the total cost of a particular sequence of actions.  The sequence must
     be composed of legal moves
    """
    util.raiseNotDefined()
           

def tinyMazeSearch(problem):
  """
  Returns a sequence of moves that solves tinyMaze.  For any other
  maze, the sequence of moves will be incorrect, so only use this for tinyMaze
  """
  from game import Directions
  s = Directions.SOUTH
  w = Directions.WEST
  return  [s,s,w,s,w,w,s,w]

def depthFirstSearch(problem):
  """
  Search the deepest nodes in the search tree first [p 85].
  
  Your search algorithm needs to return a list of actions that reaches
  the goal.  Make sure to implement a graph search algorithm [Fig. 3.7].
  
  To get started, you might want to try some of these simple commands to
  understand the search problem that is being passed in:
  """
  #print "Start:", problem.startingState()
  #print "Is the start a goal?", problem.isGoal(problem.startingState())
  #print "Start's successors:", problem.successorStates(problem.startingState())
 
  from game import Directions
  s = Directions.SOUTH
  w = Directions.WEST
  n = Directions.NORTH
  e = Directions.EAST
  # Create an instance of stack to be used for DFS
  dfsStack = util.Stack()
  visited = []
  goalPath = []

  #goalFound = problem.isGoal(problem.startingState())
  # When game begins, push the starting node on top of the stack
  dfsStack.push(problem.startingState())
  visited.append(problem.startingState())
  for fringe in problem.successorStates(problem.startingState()):
    dfsStack.push(fringe)
  while (not dfsStack.isEmpty()):
    currentState = dfsStack.pop()
    dfsStack.push(currentState)
    position, action, stepCost = currentState
    if position not in visited:
        visited.append(position)
        goalPath.append(action)
        if(problem.isGoal(position)):
            return (goalPath)
        for fringe in problem.successorStates(position):
            dfsStack.push(fringe)
    else:
        dfsStack.pop()
        if action == goalPath[-1]:
            goalPath.pop()



def breadthFirstSearch(problem):
  "Search the shallowest nodes in the search tree first. [p 81]"
  from game import Directions
  s = Directions.SOUTH
  w = Directions.WEST
  n = Directions.NORTH
  e = Directions.EAST
  # Create an instance of stack to be used for DFS
  frontier = util.Queue()
  visited = []
  #goalFound = problem.isGoal(problem.startingState())
  # When game begins, push the starting node on top of the stack
  frontier.push(problem.startingState())
  #print "Starting State: ", problem.startingState()
  frontier.pop()
  visited.append(problem.startingState())
  for fringe in problem.successorStates(problem.startingState()):
    frontier.push((fringe,[]))

  while (not frontier.isEmpty()):
    currentState, goalPath = frontier.pop()
    position, action, stepCost = currentState
    #print "Current State: ", currentState
    if position not in visited:
      visited.append(position)
      #print "Adding position to goal: ", position, action
      goalPath = goalPath + [action]
      if problem.isGoal(position):
        return goalPath
      for fringe in problem.successorStates(position):
        frontier.push((fringe,goalPath))
     
def uniformCostSearch(problem):
  "Search the node of least total cost first. "
  from game import Directions
  s = Directions.SOUTH
  w = Directions.WEST
  n = Directions.NORTH
  e = Directions.EAST
  # Create an instance of stack to be used for DFS
  frontier = util.PriorityQueue()
  visited = []
  #goalFound = problem.isGoal(problem.startingState())
  # When game begins, push the starting node on top of the stack
  frontier.push(problem.startingState(), 0)
  #print "Starting State: ", problem.startingState()
  frontier.pop()
  visited.append(problem.startingState())
  for fringe in problem.successorStates(problem.startingState()):
    position_fringe, action_fringe, stepCost_fringe = fringe
    frontier.push((fringe,[]), stepCost_fringe)

  while (not frontier.isEmpty()):
    currentState, goalPath = frontier.pop()
    position, action, stepCost = currentState
    #print "Current State: ", currentState
    if position not in visited:
      visited.append(position)
      #print "Adding action to goal: ", action
      goalPath = goalPath + [action]
      if problem.isGoal(position):
        return goalPath
      for fringe in problem.successorStates(position):
        #position_fringe, action_fringe, stepCost_fringe = fringe
        frontier.push((fringe,goalPath), problem.actionsCost(goalPath)+stepCost_fringe)

def nullHeuristic(state, problem=None):
  """
  A heuristic function estimates the cost from the current state to the nearest
  goal in the provided SearchProblem.  This heuristic is trivial.
  """

  return 0

def aStarSearch(problem, heuristic=nullHeuristic):
  "Search the node that has the lowest combined cost and heuristic first."
  from game import Directions
  s = Directions.SOUTH
  w = Directions.WEST
  n = Directions.NORTH
  e = Directions.EAST
  # Create an instance of stack to be used for DFS
  frontier = util.PriorityQueue()
  visited = []
  #goalFound = problem.isGoal(problem.startingState())
  # When game begins, push the starting node on top of the stack
  frontier.push(problem.startingState(), 0)
  #print "Starting State: ", problem.startingState()
  frontier.pop()
  visited.append(problem.startingState())
  for fringe in problem.successorStates(problem.startingState()):
    position_fringe, action_fringe, stepCost_fringe = fringe
    frontier.push((fringe,[]), stepCost_fringe)

  while (not frontier.isEmpty()):
    currentState, goalPath = frontier.pop()
    position, action, stepCost = currentState
    #print "Current State: ", currentState
    if position not in visited:
      visited.append(position)
      #print "Adding action to goal: ", action
      goalPath = goalPath + [action]
      if problem.isGoal(position):
        return goalPath
      for fringe in problem.successorStates(position):
        position_fringe, action_fringe, stepCost_fringe = fringe
        frontier.push((fringe,goalPath), problem.actionsCost(goalPath)+stepCost_fringe+heuristic(position_fringe,problem))
        #print "g(n) is: ", problem.actionsCost(goalPath)+stepCost_fringe
        #print "h(n) is: ", heuristic(position_fringe,problem)
        #print "f(n) is: ", problem.actionsCost(goalPath)+stepCost_fringe+heuristic(position_fringe,problem)
    
  
# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
ucs = uniformCostSearch
