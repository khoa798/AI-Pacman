# multiAgents.py
# --------------
# Licensing Information: Please do not distribute or publish solutions to this
# project. You are free to use and extend these projects for educational
# purposes. The Pacman AI projects were developed at UC Berkeley, primarily by
# John DeNero (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# For more info, see http://inst.eecs.berkeley.edu/~cs188/sp09/pacman.html

from util import manhattanDistance
from game import Directions
import random, util

from game import Agent

# Written with thanks to pseucode provided at:
# http://giocc.com/concise-implementation-of-minimax-through-higher-order-functions.html

class ReflexAgent(Agent):
  """
    A reflex agent chooses an action at each choice point by examining
    its alternatives via a state evaluation function.

    The code below is provided as a guide.  You are welcome to change
    it in any way you see fit, so long as you don't touch our method
    headers.
  """


  def getAction(self, gameState):
    """
    You do not need to change this method, but you're welcome to.

    getAction chooses among the best options according to the evaluation function.

    Just like in the previous project, getAction takes a GameState and returns
    some Directions.X for some X in the set {North, South, West, East, Stop}
    """
    # Collect legal moves and successor states
    legalMoves = gameState.getLegalActions()

    # Choose one of the best actions
    scores = [self.evaluationFunction(gameState, action) for action in legalMoves]
    #print "scores list is: ", scores
    bestScore = max(scores)
    #print "bestScore is: ", bestScore
    bestIndices = [index for index in range(len(scores)) if scores[index] == bestScore]
    #print "bestIndices is: ", bestIndices
    chosenIndex = random.choice(bestIndices) # Pick randomly among the best
    #print "chosenIndex is: ", chosenIndex

    "Add more of your code here if you want to"

    return legalMoves[chosenIndex]

  def evaluationFunction(self, currentGameState, action):
    """
    Design a better evaluation function here.

    The evaluation function takes in the current and proposed successor
    GameStates (pacman.py) and returns a number, where higher numbers are better.

    The code below extracts some useful information from the state, like the
    remaining food (oldFood) and Pacman position after moving (newPos).
    newScaredTimes holds the number of moves that each ghost will remain
    scared because of Pacman having eaten a power pellet.

    Print out these variables to see what you're getting, then combine them
    to create a masterful evaluation function.
    """
    # Useful information you can extract from a GameState (pacman.py)
    successorGameState = currentGameState.generatePacmanSuccessor(action)
    newPosition = successorGameState.getPacmanPosition()
    oldFood = currentGameState.getFood()
    newGhostStates = successorGameState.getGhostStates()
    newScaredTimes = [ghostState.scaredTimer for ghostState in newGhostStates]


    "*** YOUR CODE HERE ***"
    ghostPositions = successorGameState.getGhostPositions();
    #print "ghostPositions is: ", ghostPositions
    foodSeen = []
    unvisitedFood = []
    foodPosition = oldFood.asList();
    currentPosition = currentGameState.getPacmanPosition()
    #print "currentPosition is: ", currentPosition
    manhattanSum = 0
    control = 0
    closestFoodDistance = 999




    for i in range(len(foodPosition)):
        if foodPosition[i] not in foodSeen:
            unvisitedFood.append(foodPosition[i])
            

    for goalTuple in unvisitedFood:
        manhattanSum = manhattanDistance(currentPosition, goalTuple)
        if manhattanSum < closestFoodDistance:
            closestFoodDistance = manhattanSum
            closestFoodTuple = goalTuple
        #unvisitedFood.remove(closestFoodTuple)

    successorScore = successorGameState.getScore()
    ghostManhattan = manhattanDistance(ghostPositions[0], newPosition)


    " Check if the next action gets us closer to the food item, prioritize that"
    if manhattanDistance(newPosition, closestFoodTuple) < closestFoodDistance:
        if ghostManhattan<4:
            if closestFoodDistance == 0:
              return successorScore
            else:
              return successorScore+ghostManhattan/(closestFoodDistance*6)
        else:
            if closestFoodDistance == 0:
              return successorScore
            else:
              return successorScore+ghostManhattan*2/(closestFoodDistance)
    else:
      return successorScore+ghostManhattan/(closestFoodDistance*6)

    "However, allow us to move away from a food item if the situations require it(ghost nearby)"



def scoreEvaluationFunction(currentGameState):
  """
    This default evaluation function just returns the score of the state.
    The score is the same one displayed in the Pacman GUI.

    This evaluation function is meant for use with adversarial search agents
    (not reflex agents).
  """
  return currentGameState.getScore()

class MultiAgentSearchAgent(Agent):
  """
    This class provides some common elements to all of your
    multi-agent searchers.  Any methods defined here will be available
    to the MinimaxPacmanAgent, AlphaBetaPacmanAgent & ExpectimaxPacmanAgent.

    You *do not* need to make any changes here, but you can if you want to
    add functionality to all your adversarial search agents.  Please do not
    remove anything, however.

    Note: this is an abstract class: one that should not be instantiated.  It's
    only partially specified, and designed to be extended.  Agent (game.py)
    is another abstract class.
  """

  def __init__(self, evalFn = 'scoreEvaluationFunction', depth = '2'):
    self.index = 0 # Pacman is always agent index 0
    self.evaluationFunction = util.lookup(evalFn, globals())
    self.treeDepth = int(depth)

class MinimaxAgent(MultiAgentSearchAgent):
  """
    Your minimax agent (question 2)
  """
  def getAction(self, gameState):
    """
      Returns the minimax action from the current gameState using self.treeDepth
      and self.evaluationFunction.

      Here are some method calls that might be useful when implementing minimax.

      gameState.getLegalActions(agentIndex):
        Returns a list of legal actions for an agent
        agentIndex=0 means Pacman, ghosts are >= 1

      Directions.STOP:
        The stop direction, which is always legal

      gameState.generateSuccessor(agentIndex, action):
        Returns the successor game state after an agent takes an action

      gameState.getNumAgents():
        Returns the total number of agents in the game
    """
    "*** YOUR CODE HERE ***"
    agent_pacman = 0
    def minimax(state, treeDepth):
        legalMoves = state.getLegalActions(agent_pacman)
        best_move = legalMoves[0]
        best_value = float("-inf")
        for move in legalMoves:
            gameClone = state.generateSuccessor(agent_pacman, move)
            value = min_value(gameClone, treeDepth, 1)
            if value > best_value:
                best_move = move
                best_value = value
        return best_move


    def min_value(state, treeDepth, ghostAgent):
        if state.isLose() or state.isWin() or treeDepth == self.treeDepth-1:
            return self.evaluationFunction(state)
        best_value = float("inf")
        nextAgent = ghostAgent+1
        legalMoves = state.getLegalActions(ghostAgent)
        if Directions.STOP in legalMoves:
            legalMoves.remove(Directions.STOP)
        "Check if we are on the last agent if so, we move back to Pacman"
        if ghostAgent == (state.getNumAgents()-1):
            nextAgent = agent_pacman
        #best_move = legalMoves[0]
        for move in legalMoves:
            if nextAgent == agent_pacman:
                gameClone = state.generateSuccessor(ghostAgent, move)
                value = max_value(gameClone, treeDepth+1)
            else:
                gameClone = state.generateSuccessor(ghostAgent, move)
                value = min_value(gameClone, treeDepth, nextAgent)
            if value < best_value:
                #best_move = move
                best_value = value
        return best_value

    def max_value(state, treeDepth):
        #legalMoves = gameState.getLegalActions()
        if state.isLose() or state.isWin() or treeDepth == self.treeDepth-1:
            return self.evaluationFunction(state)
        best_value = float("-inf")
        legalMoves = state.getLegalActions(agent_pacman)
        legalMoves.remove(Directions.STOP)
        best_move = legalMoves[0]
        for move in legalMoves:
            gameClone = state.generateSuccessor(agent_pacman, move)
            value = min_value(gameClone, treeDepth, 1)
            if value > best_value:
                best_move = move
                best_value = value
        return best_value

    return minimax(gameState, 0)

class AlphaBetaAgent(MultiAgentSearchAgent):
  """
    Your minimax agent with alpha-beta pruning (question 3)
  """

  def getAction(self, gameState):
    """
      Returns the minimax action using self.treeDepth and self.evaluationFunction
    """
    "*** YOUR CODE HERE ***"
    agent_pacman = 0
    def minimax(state, treeDepth):
        legalMoves = state.getLegalActions(agent_pacman)
        best_move = legalMoves[0]
        best_value = float("-inf")
        for move in legalMoves:
            gameClone = state.generateSuccessor(agent_pacman, move)
            value = min_value(gameClone, treeDepth, 1, float("-inf"), float("inf"))
            if value > best_value:
                best_move = move
                best_value = value
        return best_move


    def min_value(state, treeDepth, ghostAgent, alpha, beta):
        if state.isLose() or state.isWin() or treeDepth == self.treeDepth-1:
            return self.evaluationFunction(state)
        best_value = beta
        nextAgent = ghostAgent+1
        legalMoves = state.getLegalActions(ghostAgent)
        if Directions.STOP in legalMoves:
            legalMoves.remove(Directions.STOP)
        "Check if we are on the last agent if so, we move back to Pacman"
        if ghostAgent == (state.getNumAgents()-1):
            nextAgent = agent_pacman
        for move in legalMoves:
            if nextAgent == agent_pacman:
                gameClone = state.generateSuccessor(ghostAgent, move)
                value = max_value(gameClone, treeDepth+1, alpha, beta)
            else:
                gameClone = state.generateSuccessor(ghostAgent, move)
                value = min_value(gameClone, treeDepth, nextAgent, alpha, beta)
            if value < best_value:
                best_value = value
            beta = min(best_value, beta)
            if best_value <= alpha:
                break
        return best_value

    def max_value(state, treeDepth, alpha, beta):
        if state.isLose() or state.isWin() or treeDepth == self.treeDepth-1:
            return self.evaluationFunction(state)
        best_value = alpha
        legalMoves = state.getLegalActions(agent_pacman)
        legalMoves.remove(Directions.STOP)
        best_move = legalMoves[0]
        for move in legalMoves:
            gameClone = state.generateSuccessor(agent_pacman, move)
            value = min_value(gameClone, treeDepth, 1, alpha, beta)
            if value > best_value:
                best_move = move
                best_value = value
            alpha = max(best_value, alpha)
            if beta <= best_value:
                break
        return best_value

    return minimax(gameState, 0)


class ExpectimaxAgent(MultiAgentSearchAgent):
  """
    Your expectimax agent (question 4)
  """

  def getAction(self, gameState):
    """
      Returns the expectimax action using self.treeDepth and self.evaluationFunction

      All ghosts should be modeled as choosing uniformly at random from their
      legal moves.
    """
    "*** YOUR CODE HERE ***"
    agent_pacman = 0
    def minimax(state, treeDepth, isPacman, currAgent):
        if state.isLose() or state.isWin() or treeDepth == self.treeDepth-1:
            return self.evaluationFunction(state)
        if isPacman == True:
            return max_value(state, treeDepth, True)
        else:
            return exp_value(state, treeDepth+1, currAgent, False)

    def exp_value(state, treeDepth, ghostAgent, isPacman):
        if state.isLose() or state.isWin() or treeDepth == self.treeDepth-1:
            return self.evaluationFunction(state)
        best_value = 0
        value = best_value
        nextAgent = ghostAgent+1
        legalMoves = state.getLegalActions(ghostAgent)
        if len(legalMoves) == 0:
            probability = 1
        else:
            probability = 1/len(legalMoves)
        if Directions.STOP in legalMoves:
            legalMoves.remove(Directions.STOP)
        "Check if we are on the last agent if so, we move back to Pacman"
        if ghostAgent == (state.getNumAgents()-1):
            nextAgent = agent_pacman
        #best_move = legalMoves[0]
        for move in legalMoves:
            if nextAgent == agent_pacman:
                gameClone = state.generateSuccessor(ghostAgent, move)
                mValue = minimax(gameClone, treeDepth+1, True)
                if type(mValue) is int:
                    value += mValue * probability
                else:
                    intValue, move = mValue
                    value += intValue * probability
            else:
                gameClone = state.generateSuccessor(ghostAgent, move)
                value += minimax(gameClone, treeDepth, False, nextAgent) * probability
            if value < best_value:
                best_value = value
        return best_value

    def max_value(state, treeDepth, isPacman):
        #legalMoves = gameState.getLegalActions()
        if state.isLose() or state.isWin() or treeDepth == self.treeDepth-1:
            return self.evaluationFunction(state)
        best_value = float("-inf")
        legalMoves = state.getLegalActions(agent_pacman)
        legalMoves.remove(Directions.STOP)
        best_move = legalMoves[0]
        for move in legalMoves:
            gameClone = state.generateSuccessor(agent_pacman, move)
            "Sum over all values then divide by number of ghosts"
            value = minimax(gameClone, treeDepth, False, 1)
            if value > best_value:
                best_move = move
                best_value = value
        return (best_value, best_move)

    return minimax(gameState, 0, True, 0)[1]

def betterEvaluationFunction(currentGameState):
  """
    Your extreme ghost-hunting, pellet-nabbing, food-gobbling, unstoppable
    evaluation function (question 5).

    DESCRIPTION: Create a list of the closest food items and go to them, very simple
    Not as complex so I would not ensure consistently high scores. The ratio is one i used from earlier but
    with adjusted values as the other ones were not that good.
  """
  "*** YOUR CODE HERE ***"
  #successorGameState = currentGameState.generatePacmanSuccessor(action)
  #successorGameState = currentGameState.generateSuccessor(0,move)
  oldFood = currentGameState.getFood()
  newGhostStates = currentGameState.getGhostStates()
  newScaredTimes = [ghostState.scaredTimer for ghostState in newGhostStates]
  ghostPositions = currentGameState.getGhostPositions();
  foodSeen = []
  unvisitedFood = []
  ghostDistances = []
  foodDistances = []
  foodPosition = oldFood.asList();
  currentPosition = currentGameState.getPacmanPosition()
  manhattanSum = 0
  control = 0
  closestFoodDistance = 999


  for ghostTuple in ghostPositions:
    manhattanSum = manhattanDistance(ghostTuple, currentPosition)
    ghostDistances.append(manhattanSum)

  for goalTuple in foodPosition:
    manhattanSum = manhattanDistance(goalTuple, currentPosition)
    foodDistances.append(manhattanSum)

 # for i in range(len(foodPosition)):
 #     if foodPosition[i] not in foodSeen:
 #         unvisitedFood.append(foodPosition[i])

#  for goalTuple in unvisitedFood:
#      manhattanSum = manhattanDistance(currentPosition, goalTuple)
#      if manhattanSum < closestFoodDistance:
#          closestFoodDistance = manhattanSum
#          closestFoodTuple = goalTuple


  successorScore = currentGameState.getScore()
  #ghostManhattan = manhattanDistance(ghostPositions[0], currentPosition)

  if  len(foodDistances) > 0 and min(foodDistances) != 0:
    smallestGhostDistance = min (ghostDistances)
    smallestFoodPosition = min (foodDistances)
    return successorScore + sum(newScaredTimes)*(0.6)  + smallestGhostDistance/smallestFoodPosition*2
  else:
    return successorScore


# Abbreviation
better = betterEvaluationFunction

class ContestAgent(MultiAgentSearchAgent):
  """
    Your agent for the mini-contest
  """

  def getAction(self, gameState):
    """
      Returns an action.  You can use any method you want and search to any depth you want.
      Just remember that the mini-contest is timed, so you have to trade off speed and computation.

      Ghosts don't behave randomly anymore, but they aren't perfect either -- they'll usually
      just make a beeline straight towards Pacman (or away from him if they're scared!)
    """
    "*** YOUR CODE HERE ***"
    util.raiseNotDefined()

