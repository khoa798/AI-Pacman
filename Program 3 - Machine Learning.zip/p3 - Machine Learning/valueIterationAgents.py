# valueIterationAgents.py
# -----------------------
# Licensing Information: Please do not distribute or publish solutions to this
# project. You are free to use and extend these projects for educational
# purposes. The Pacman AI projects were developed at UC Berkeley, primarily by
# John DeNero (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# For more info, see http://inst.eecs.berkeley.edu/~cs188/sp09/pacman.html

import mdp, util

from learningAgents import ValueEstimationAgent

class ValueIterationAgent(ValueEstimationAgent):
  """
      * Please read learningAgents.py before reading this.*

      A ValueIterationAgent takes a Markov decision process
      (see mdp.py) on initialization and runs value iteration
      for a given number of iterations using the supplied
      discount factor.
  """
  def __init__(self, mdp, discountRate = 0.9, iters = 100):
    """
      Your value iteration agent should take an mdp on
      construction, run the indicated number of iterations
      and then act according to the resulting policy.

      Some useful mdp methods you will use:
          mdp.getStates()
          mdp.getPossibleActions(state)
          mdp.getTransitionStatesAndProbs(state, action)
          mdp.getReward(state, action, nextState)
    """
    self.mdp = mdp
    self.discountRate = discountRate
    self.iters = iters
    self.values = util.Counter() # A Counter is a dict with default 0

    """Description:
    After writing the necessary functions for our Value Iteration Agent,
    We need to actually construct the MDP and compute its values
    the code does the following below
    """
    """ YOUR CODE HERE """
    for episode in range(self.iters):
        maxQValues = util.Counter()
        for state in self.mdp.getStates():
          maxValue = float("-inf")    
          legalActions = self.mdp.getPossibleActions(state)
          for action in legalActions:
              currentQValue = self.getQValue(state,action)
              if currentQValue > maxValue:
                  maxValue = currentQValue
                  maxQValues[state] = maxValue
                  #self.values[state] = maxValue
        self.values = maxQValues

  #  for state in self.mdp.getStates():
  #      print "State value of ", state, "is: ", self.values[state]


    
    """ END CODE """

  def getValue(self, state):
    """
      Return the value of the state (computed in __init__).

    """
    return self.values[state]


  def getQValue(self, state, action):
    """
      The q-value of the state action pair
      (after the indicated number of value iteration
      passes).  Note that value iteration does not
      necessarily create this quantity and you may have
      to derive it on the fly.

    """
    """Description:
    To do this I need to know every value of me making my move
    So first, I need to calculate the probability of every move with their
    respective rewards with the discount and sum them all together.
    Thus I get the following below.
    """
    """ YOUR CODE HERE """
    totalQValue = 0
    for nextState, probability in self.mdp.getTransitionStatesAndProbs(state,action):
        nextStateValue = self.getValue(nextState)
        reward = self.mdp.getReward(state,action,nextState)
        totalQValue += probability * (reward + self.discountRate*nextStateValue)
    return totalQValue

    
    """ END CODE """

  def getPolicy(self, state):
    """
      The policy is the best action in the given state
      according to the values computed by value iteration.
      You may break ties any way you see fit.  Note that if
      there are no legal actions, which is the case at the
      terminal state, you should return None.
    """

    """Description:
    First check if there are anymore legal actions for this state,
    once that's done, we simpy just return the best action based
    on the Q Values
    """
    """ YOUR CODE HERE """
    bestPolicyValue = float("-inf")
    bestAction = None
    if self.mdp.isTerminal(state):
        return None
    else:
        legalActions = self.mdp.getPossibleActions(state)
        for action in legalActions:
            tempVal = self.getQValue(state, action)
            if tempVal >= bestPolicyValue:
                bestAction = action
                bestPolicyValue = tempVal
        return bestAction

    """ END CODE """

  def getAction(self, state):
    "Returns the policy at the state (no exploration)."
    return self.getPolicy(state)
