# myTeam.py
# ---------
# Licensing Information: Please do not distribute or publish solutions to this
# project. You are free to use and extend these projects for educational
# purposes. The Pacman AI projects were developed at UC Berkeley, primarily by
# John DeNero (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# For more info, see http://inst.eecs.berkeley.edu/~cs188/sp09/pacman.html

from captureAgents import CaptureAgent
import random, time, util
from game import Directions, Actions
import game
from util import nearestPoint

#################
# Team creation #
#################

def createTeam(firstIndex, secondIndex, isRed,
               first = 'QLearningAgent', second = 'QLearningAgent'):
  """
  This function should return a list of two agents that will form the
  team, initialized using firstIndex and secondIndex as their agent
  index numbers.  isRed is True if the red team is being created, and
  will be False if the blue team is being created.

  As a potentially helpful development aid, this function can take
  additional string-valued keyword arguments ("first" and "second" are
  such arguments in the case of this function), which will come from
  the --redOpts and --blueOpts command-line arguments to capture.py.
  For the nightly contest, however, your team will be created without
  any extra arguments, so you should make sure that the default
  behavior is what you want for the nightly contest.
  """

  # The following line is an example only; feel free to change it.
  return [eval(first)(firstIndex), eval(second)(secondIndex)]

##########
# Agents #
##########

class AttackAgent(CaptureAgent):
  """
  A Dummy agent to serve as an example of the necessary agent structure.
  You should look at baselineTeam.py for more details about how to
  create an agent as this is the bare minimum.
  """

  def registerInitialState(self, gameState):
    """
    This method handles the initial setup of the
    agent to populate useful fields (such as what team
    we're on). 
    
    A distanceCalculator instance caches the maze distances
    between each pair of positions, so your agents can use:
    self.distancer.getDistance(p1, p2)

    IMPORTANT: This method may run for at most 15 seconds.
    """

    ''' 
    Make sure you do not delete the following line. If you would like to
    use Manhattan distances instead of maze distances in order to save
    on initialization time, please take a look at
    CaptureAgent.registerInitialState in captureAgents.py. 
    '''
    CaptureAgent.registerInitialState(self, gameState)
    self.myAgents = CaptureAgent.getTeam(self, gameState)
    self.opAgents = CaptureAgent.getOpponents(self, gameState)
    self.myFoods = CaptureAgent.getFood(self, gameState).asList()
    self.opFoods = CaptureAgent.getFoodYouAreDefending(self, gameState).asList()

  # Finds the next successor which is a grid position (location tuple).
  def getSuccessor(self, gameState, action):
    successor = gameState.generateSuccessor(self.index, action)
    pos = successor.getAgentState(self.index).getPosition()
    if pos != nearestPoint(pos):
      # Only half a grid position was covered
      return successor.generateSuccessor(self.index, action)
    else:
      return successor

  # Returns a counter of features for the state
  def getFeatures(self, gameState, action):
    features = util.Counter()
    successor = self.getSuccessor(gameState, action)
    features['successorScore'] = self.getScore(successor)
    myPos = successor.getAgentState(self.index).getPosition()

    # Compute distance to the nearest food
    foodList = self.getFood(successor).asList()
    if len(foodList) > 0: # This should always be True,  but better safe than sorry
      minDistance = min([self.getMazeDistance(myPos, food) for food in foodList])
      features['distanceToFood'] = minDistance

    # Compute distance to nearest ghost
    ghostDist = []
    for opponent in self.opAgents:
      opPos = successor.getAgentPosition(opponent)
      if opPos != None:
        ghostDist.append(self.getMazeDistance(myPos, opPos))
      else:
        ghostDist.append(successor.getAgentDistances()[opponent])
    features['closestGhost'] = min(ghostDist)

    return features

  # Returns a dictionary of features for the state
  def getWeights(self, gameState, action):
    return {'successorScore': 100, 'distanceToFood': -1, 'closestGhost': 3}

  # Computes a linear combination of features and feature weights
  def evaluate(self, gameState, action):
    features = self.getFeatures(gameState, action)
    weights = self.getWeights(gameState, action)
    return features * weights

  # Choose the best action for the current agent to take
  def chooseAction(self, gameState):
    agentPos = gameState.getAgentPosition(self.index)
    actions = gameState.getLegalActions(self.index)

    # Distances between agent and foods
    distToFood = []
    for food in self.myFoods:
      distToFood.append(self.distancer.getDistance(agentPos, food))

    # Distances between agent and opponents
    distToOps = []
    for opponent in self.opAgents:
      opPos = gameState.getAgentPosition(opponent)
      if opPos != None:
        distToOps.append(self.distancer.getDistance(agentPos, opPos))
    

    # You can profile your evaluation time by uncommenting these lines
    # start = time.time()
    values = [self.evaluate(gameState, a) for a in actions]
    # print 'eval time for agent %d: %.4f' % (self.index, time.time() - start)
    maxValue = max(values)
    bestActions = [a for a, v in zip(actions, values) if v == maxValue]
    return random.choice(bestActions)

class QLearningAgent(CaptureAgent):
  """
    Q-Learning Agent

    Instance variables you have access to
      - self.epsilon (exploration prob)
      - self.alpha (learning rate)
      - self.discountRate (discount rate)
  """

  def registerInitialState(self, gameState):
    """
    This method handles the initial setup of the
    agent to populate useful fields (such as what team
    we're on). 
    
    A distanceCalculator instance caches the maze distances
    between each pair of positions, so your agents can use:
    self.distancer.getDistance(p1, p2)

    IMPORTANT: This method may run for at most 15 seconds.
    """

    ''' 
    Make sure you do not delete the following line. If you would like to
    use Manhattan distances instead of maze distances in order to save
    on initialization time, please take a look at
    CaptureAgent.registerInitialState in captureAgents.py. 
    '''
    CaptureAgent.registerInitialState(self, gameState)

    self.epsilon = 0.1 #exploration prob
    self.alpha = 0.2 #learning rate
    self.discountRate = 0.8
    self.weights = util.Counter()
    """
    Open weights file if it exists, otherwise start with empty weights.
    NEEDS TO BE CHANGED BEFORE SUBMISSION
    """
    try:
      with open('weights.txt', "r") as file:
        self.weights = eval(file.read())
    except IOError:
        return


  #------------------------------- Q-learning Functions -------------------------------

  """
  Iterate through all features (closest food, bias, ghost dist),
  multiply each of the features' value to the feature's weight,
  and return the sum of all these values to get the q-value.
  """
  def getQValue(self, gameState, action):
    features = self.getFeatures(gameState, action)
    return features * self.weights

  """
  Iterate through all q-values that we get from all
  possible actions, and return the highest q-value
  """
  def getValue(self, gameState):
    qVals = []
    legalActions = gameState.getLegalActions(self.index)
    if len(legalActions) == 0:
      return 0.0
    else:
      for action in legalActions:
        qVals.append(self.getQValue(gameState, action))
      return max(qVals)

  """
  Iterate through all q-values that we get from all
  possible actions, and return the action associated
  with the highest q-value.
  """
  def getPolicy(self, gameState):
    values = []
    legalActions = gameState.getLegalActions(self.index)
    legalActions.remove(Directions.STOP)
    if len(legalActions) == 0:
      return None
    else:
      for action in legalActions:
        #self.updateWeights(gameState, action)
        values.append((self.getQValue(gameState, action), action))
    return max(values)[1]

  """
  Calculate probability of 0.1.
  If probability is < 0.1, then choose a random action from
  a list of legal actions.
  Otherwise use the policy defined above to get an action.
  """
  def chooseAction(self, gameState):
    # Pick Action
    legalActions = gameState.getLegalActions(self.index)
    action = None

    if len(legalActions) != 0:
      prob = util.flipCoin(self.epsilon)
      if prob:
        action = random.choice(legalActions)
      else:
        action = self.getPolicy(gameState)
    return action


  #------------------------------ Features And Weights --------------------------------

  # Define features to use. NEEDS WORK
  def getFeatures(self, gameState, action):
    # Extract the grid of food and wall locations
    food = gameState.getBlueFood()
    walls = gameState.getWalls()
    ghosts = []
    # Get ghost locations if observable
    if gameState.getAgentPosition(1) != None:
      ghosts.append(gameState.getAgentPosition(1))
    if gameState.getAgentPosition(3) != None:
      ghosts.append(gameState.getAgentPosition(3))
    
    # Initialize features
    features = util.Counter()
    successor = self.getSuccessor(gameState, action)

    # Successor Score
    features['successorScore'] = self.getScore(successor)

    # Bias
    features["bias"] = 1.0
    
    # compute the location of pacman after he takes the action
    x, y = gameState.getAgentPosition(self.index)
    dx, dy = Actions.directionToVector(action)
    next_x, next_y = int(x + dx), int(y + dy)
    
    # Ghosts 1-step away
    #features["#-of-ghosts-1-step-away"] = sum((next_x, next_y) in Actions.getLegalNeighbors(g, walls) for g in ghosts)
    ghostDist = []
    for ghost in ghosts:
    	ghostDist.append(self.distancer.getDistance((next_x, next_y), ghost))
    if ghostDist:
    	#sqrt of closest ghost distance
    	features['closest-ghost'] = (min(ghostDist) ** 0.5)
    else:
    	features['closest-ghost'] = 0.0

    # if there is no danger of ghosts then add the food feature
    if not features["#-of-ghosts-1-step-away"] and food[next_x][next_y]:
      features["eats-food"] = 1.0
    
    # Closest food
    dist = self.closestFood((next_x, next_y), food, walls)
    if dist is not None:
      # make the distance a number less than one otherwise the update
      # will diverge wildly
      features["closest-food"] = float(dist) / (walls.width * walls.height) 

    # Normalize and return
    features.divideAll(10.0)
    return features

  """
  Iterate through all features and for each feature, update
  its weight values using the following formula:
  w(i) = w(i) + alpha((reward + discount*value(nextState)) - Q(s,a)) * f(i)(s,a)
  """
  def updateWeights(self, gameState, action):
    features = self.getFeatures(gameState, action)
    nextState = self.getSuccessor(gameState, action)

    # Calculate the reward. NEEDS WORK
    reward = nextState.getScore() - gameState.getScore()

    for feature in features:
      correction = (reward + self.discountRate*self.getValue(nextState)) - self.getQValue(gameState, action)
      self.weights[feature] = self.weights[feature] + self.alpha*correction * features[feature]


  #-------------------------------- Helper Functions ----------------------------------

  # Finds the next successor which is a grid position (location tuple).
  def getSuccessor(self, gameState, action):
    successor = gameState.generateSuccessor(self.index, action)
    pos = successor.getAgentState(self.index).getPosition()
    if pos != nearestPoint(pos):
      # Only half a grid position was covered
      return successor.generateSuccessor(self.index, action)
    else:
      return successor

  def closestFood(self, pos, food, walls):
    fringe = [(pos[0], pos[1], 0)]
    expanded = set()
    while fringe:
      pos_x, pos_y, dist = fringe.pop(0)
      if (pos_x, pos_y) in expanded:
        continue
      expanded.add((pos_x, pos_y))
      # if we find a food at this location then exit
      if food[pos_x][pos_y]:
        return dist
      # otherwise spread out from the location to its neighbours
      nbrs = Actions.getLegalNeighbors((pos_x, pos_y), walls)
      for nbr_x, nbr_y in nbrs:
        fringe.append((nbr_x, nbr_y, dist+1))
    # no food found
    return None

  # Update weights file at the end of each game
  def final(self, gameState):
    print self.weights
    file = open('weights.txt', 'w')
    file.write(str(self.weights))