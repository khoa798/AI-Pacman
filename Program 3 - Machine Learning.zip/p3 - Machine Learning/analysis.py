# analysis.py
# -----------
# Licensing Information: Please do not distribute or publish solutions to this
# project. You are free to use and extend these projects for educational
# purposes. The Pacman AI projects were developed at UC Berkeley, primarily by
# John DeNero (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# For more info, see http://inst.eecs.berkeley.edu/~cs188/sp09/pacman.html

######################
# ANALYSIS QUESTIONS #
######################

# Change these default values to obtain the specified policies through
# value iteration.

def question2():
  answerDiscount = 0.9
  answerNoise = 0
  """Description:
  Changed noise to 0 since this will always let the agent cross the bridge
  with green values
  """
  """ YOUR CODE HERE """

  """ END CODE """
  return answerDiscount, answerNoise

def question3a():
  answerDiscount = 0.2
  answerNoise = 0
  answerLivingReward = -0.2
  """Description:
  With a penalty to living and lower incentive to make moves for more rewards
  and lastly, no risk of making the wrong move... the agent will risk the
  cliffs and head straight for the nearest reward
  """
  """ YOUR CODE HERE """

  """ END CODE """
  return answerDiscount, answerNoise, answerLivingReward
  # If not possible, return 'NOT POSSIBLE'

def question3b():
  answerDiscount = 0.1
  answerNoise = 0.1
  answerLivingReward = -0.2
  """Description:
  With some slight noise the agent will not want to risk going near the cliff
  """
  """ YOUR CODE HERE """

  """ END CODE """
  return answerDiscount, answerNoise, answerLivingReward
  # If not possible, return 'NOT POSSIBLE'

def question3c():
  answerDiscount = 0.9
  answerNoise = 0
  answerLivingReward = 0.0
  """Description:
  With no noise, we can risk the cliff and head straight for maximizing rewards
  """
  """ YOUR CODE HERE """

  """ END CODE """
  return answerDiscount, answerNoise, answerLivingReward
  # If not possible, return 'NOT POSSIBLE'

def question3d():
  answerDiscount = 0.9
  answerNoise = 0.2
  answerLivingReward = 0.2
  """Description:
  slightly small living reward makes us prefer the long way
  """
  """ YOUR CODE HERE """

  """ END CODE """
  return answerDiscount, answerNoise, answerLivingReward
  # If not possible, return 'NOT POSSIBLE'

def question3e():
  answerDiscount = 0.9
  answerNoise = 0.2
  answerLivingReward = 1
  """Description:
  With a huge living reward, we want to maximize living 
  so just continue making actions
  """
  """ YOUR CODE HERE """

  """ END CODE """
  return answerDiscount, answerNoise, answerLivingReward
  # If not possible, return 'NOT POSSIBLE'

def question6():
  answerEpsilon = 0.2
  answerLearningRate = 0.9
  """Description:
  Very unlikely it would go past the bridge since the closest reward is so
  too far away, along with the fact that a large exploration rate means
  the agent would likely just continue running into negative rewards.
  """
  """ YOUR CODE HERE """

  """ END CODE """
  #return answerEpsilon, answerLearningRate
  # If not possible, return 'NOT POSSIBLE'
  return "NOT POSSIBLE"

if __name__ == '__main__':
  print 'Answers to analysis questions:'
  import analysis
  for q in [q for q in dir(analysis) if q.startswith('question')]:
    response = getattr(analysis, q)()
    print '  Question %s:\t%s' % (q, str(response))
