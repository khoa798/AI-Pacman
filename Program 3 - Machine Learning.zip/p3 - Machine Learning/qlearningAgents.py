# qlearningAgents.py
# ------------------
# Licensing Information: Please do not distribute or publish solutions to this
# project. You are free to use and extend these projects for educational
# purposes. The Pacman AI projects were developed at UC Berkeley, primarily by
# John DeNero (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# For more info, see http://inst.eecs.berkeley.edu/~cs188/sp09/pacman.html

# Special thanks to https://www.youtube.com/watch?v=qPE4CPQY7mc tutorial,
# For helping create the code for update in Q Learning algorithm

from game import *
from learningAgents import ReinforcementAgent
from featureExtractors import *

import random,util,math

class QLearningAgent(ReinforcementAgent):
  """
    Q-Learning Agent

    Functions you should fill in:
      - getQValue
      - getAction
      - getValue
      - getPolicy
      - update

    Instance variables you have access to
      - self.epsilon (exploration prob)
      - self.alpha (learning rate)
      - self.discountRate (discount rate)

    Functions you should use
      - self.getLegalActions(state)
        which returns legal actions
        for a state
  """
  def __init__(self, **args):
    "You can initialize Q-values here..."
    ReinforcementAgent.__init__(self, **args)
    self.QValue = util.Counter()



  def getQValue(self, state, action):
    """
      Returns Q(state,action)
      Should return 0.0 if we never seen
      a state or (state,action) tuple
    """
    """Description:
    Finds the Q Value of a state,action pair
    	By using the Counter structure, we always return a 0
    	for missing elements, so there is no check needed
    	for any unseen tuples.
    """
    """ YOUR CODE HERE """
    return self.QValue[(state,action)]
    """ END CODE """
    




  def getValue(self, state):
    """
      Returns max_action Q(state,action)
      where the max is over legal actions.  Note that if
      there are no legal actions, which is the case at the
      terminal state, you should return a value of 0.0.
    """
    """Description:
    Simply check for all legal actions and retrieve the action's respective
    Q Values from the state. Then grab the max value which should maximize our
    rewards.
    """
    """ YOUR CODE HERE """
    legalActions = self.getLegalActions(state)
    if not legalActions:
    	return 0.0
    else:
    	allQValues = [self.getQValue(state,action) for action in legalActions]
    	return max(allQValues)
    #bestMove = max(allQValues)

    """ END CODE """

  def getPolicy(self, state):
    """
      Compute the best action to take in a state.  Note that if there
      are no legal actions, which is the case at the terminal state,
      you should return None.
    """
    """Description:
    Similar code from Value Iteration but this time we are adding
    a random choice for values that are equal to get a better
    behavior out of our agent.
    """
    """ YOUR CODE HERE """
    bestPolicyValue = float("-inf")
    bestAction = None
    legalActions = self.getLegalActions(state)
    if not legalActions:
        return None
    else:
        for action in legalActions:
            tempVal = self.getQValue(state, action)
            if tempVal > bestPolicyValue:
              bestAction = action
              bestPolicyValue = tempVal
            elif tempVal == bestPolicyValue:
              "We will make a random choice for a better behavior"
              #(tempVal, action) is 0
              # or 
              #(bestPolicyValue, bestAction) is 1
              whichAction = [0, 1]
              if random.choice(whichAction) == 0:
                bestAction = action
                bestPolicyValue = tempVal
              else:
                "Keep the current values"
                pass
                # bestAction = bestAction
                # bestPolicyValue = bestPolicyValue
        return bestAction
    """ END CODE """

  def getAction(self, state):
    """
      Compute the action to take in the current state.  With
      probability self.epsilon, we should take a random action and
      take the best policy action otherwise.  Note that if there are
      no legal actions, which is the case at the terminal state, you
      should choose None as the action.

      HINT: You might want to use util.flipCoin(prob)
      HINT: To pick randomly from a list, use random.choice(list)
    """
    # Pick Action
    legalActions = self.getLegalActions(state)
    action = None

    """Description:
    [Enter a description of what you did here.]
    """
    """ YOUR CODE HERE """
    if not legalActions:
      return None
    else:
      if util.flipCoin(self.epsilon):
        action = random.choice(legalActions)
      else:
        action = self.getPolicy(state)

    """ END CODE """

    return action

  def update(self, state, action, nextState, reward):
    """
      The parent class calls this to observe a
      state = action => nextState and reward transition.
      You should do your Q-Value update here

      NOTE: You should never call this function,
      it will be called on your behalf
    """
    """Description:
    [Enter a description of what you did here.]
    """
    """ YOUR CODE HERE """
    updatedValue = 0
    q_predict = self.getQValue(state, action)
    notTerminal = self.getLegalActions(nextState)
    if notTerminal:
      q_target = reward + self.discountRate * self.getValue(nextState)
    else:
      q_target = reward
    updatedValue = self.getQValue(state,action) + self.alpha * (q_target - q_predict)
    self.QValue[(state,action)] = updatedValue


    """ END CODE """

class PacmanQAgent(QLearningAgent):
  "Exactly the same as QLearningAgent, but with different default parameters"

  def __init__(self, epsilon=0.05,gamma=0.8,alpha=0.2, numTraining=0, **args):
    """
    These default parameters can be changed from the pacman.py command line.
    For example, to change the exploration rate, try:
        python pacman.py -p PacmanQLearningAgent -a epsilon=0.1

    alpha    - learning rate
    epsilon  - exploration rate
    gamma    - discount factor
    numTraining - number of training episodes, i.e. no learning after these many episodes
    """
    args['epsilon'] = epsilon
    args['gamma'] = gamma
    args['alpha'] = alpha
    args['numTraining'] = numTraining
    self.index = 0  # This is always Pacman
    QLearningAgent.__init__(self, **args)

  def getAction(self, state):
    """
    Simply calls the getAction method of QLearningAgent and then
    informs parent of action for Pacman.  Do not change or remove this
    method.
    """
    action = QLearningAgent.getAction(self,state)
    self.doAction(state,action)
    return action


class ApproximateQAgent(PacmanQAgent):
  """
     ApproximateQLearningAgent

     You should only have to overwrite getQValue
     and update.  All other QLearningAgent functions
     should work as is.
  """
  def __init__(self, extractor='IdentityExtractor', **args):
    self.featExtractor = util.lookup(extractor, globals())()
    PacmanQAgent.__init__(self, **args)
    self.weight = util.Counter()

    # You might want to initialize weights here.

  def getQValue(self, state, action):
    """
      Should return Q(state,action) = w * featureVector
      where * is the dotProduct operator
    """
    """Description:
    Simply computing total Q Value based on weight*features
    """
    """ YOUR CODE HERE """
    #feats = util.Counter()
    totalQValue = 0
    feats = self.featExtractor.getFeatures(state,action)
    for feat in feats:
      totalQValue += feats[feat] * self.weight[feat]
    return totalQValue

    #return self.QValue[(state,action)] * feats
    """ END CODE """

  def update(self, state, action, nextState, reward):
    """
       Should update your weights based on transition
    """
    """Description:
    updating weights here based on formula
    """
    """ YOUR CODE HERE """
    feats = self.featExtractor.getFeatures(state,action)
    updatedValue = 0
    q_predict = self.getQValue(state, action)
    notTerminal = self.getLegalActions(nextState)
    if notTerminal:
      q_target = reward + self.discountRate * self.getValue(nextState)
    else:
      q_target = reward
    #updatedValue = self.getQValue(state,action) + self.alpha * (q_target - q_predict)
    for feat in feats:
      updatedValue = self.alpha*(q_target - q_predict) * feats[feat]
      self.weight[feat] += updatedValue
    """ END CODE """

  def final(self, state):
    "Called at the end of each game."
    # call the super-class final method
    PacmanQAgent.final(self, state)

    # did we finish training?
    if self.episodesSoFar == self.numTraining:
      # you might want to print your weights here for debugging
      #util.raiseNotDefined()
      pass